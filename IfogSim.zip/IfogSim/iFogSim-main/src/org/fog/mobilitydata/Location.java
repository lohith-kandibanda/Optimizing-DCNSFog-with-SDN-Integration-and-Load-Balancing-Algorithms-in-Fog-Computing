package org.fog.mobilitydata;


public class Location {

	public double latitude;
	public double longitude;
	public int block;
	
	public Location(double latitude, double longitude, int block) {
		// TODO Auto-generated constructor stub
		this.latitude = latitude;
		this.longitude = longitude;
		this.block = block;
	}

}
