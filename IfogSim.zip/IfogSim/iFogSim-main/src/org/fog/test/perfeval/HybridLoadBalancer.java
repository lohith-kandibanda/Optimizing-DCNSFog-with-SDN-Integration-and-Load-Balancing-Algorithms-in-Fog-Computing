package org.fog.test.perfeval;

import org.fog.entities.FogDevice;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class HybridLoadBalancer {
    private List<FogDevice> devices;
    private int currentIndex; // For Round-Robin
    private Map<FogDevice, Integer> weights; // For Weighted Load Balancing
    private Map<FogDevice, Double> latencyMap; // For Latency-Aware Routing

    public HybridLoadBalancer(List<FogDevice> devices) {
        this.devices = devices;
        this.currentIndex = 0;
        this.weights = new HashMap<>();
        this.latencyMap = new HashMap<>();

        initializeWeightsAndLatencies();
    }

    /**
     * Initializes weights and latency for all devices
     */
    private void initializeWeightsAndLatencies() {
        for (FogDevice device : devices) {
            // Assign weight based on the capacity of the device (e.g., CPU MIPS)
            weights.put(device, (int) device.getHost().getTotalMips());
            // Initialize latency to the device's uplink latency
            latencyMap.put(device, device.getUplinkLatency());
        }
    }

    /**
     * Assign tasks using the hybrid load balancing algorithm
     */
    public FogDevice assignTask() {
        // Perform Latency-Aware Routing first
        FogDevice latencyOptimizedDevice = getLowestLatencyDevice();
        if (latencyOptimizedDevice != null) {
            return latencyOptimizedDevice;
        }

        // If no latency-based optimization is possible, fall back to Weighted Load Balancing
        FogDevice weightedDevice = getWeightedDevice();
        if (weightedDevice != null) {
            return weightedDevice;
        }

        // Finally, fall back to Round-Robin as a last resort
        return getNextRoundRobinDevice();
    }

    /**
     * Select the device with the lowest latency
     */
    private FogDevice getLowestLatencyDevice() {
        double minLatency = Double.MAX_VALUE;
        FogDevice selectedDevice = null;

        for (FogDevice device : devices) {
            double currentLatency = latencyMap.getOrDefault(device, Double.MAX_VALUE);
            if (currentLatency < minLatency) {
                minLatency = currentLatency;
                selectedDevice = device;
            }
        }
        return selectedDevice;
    }

    /**
     * Select the device based on weighted load balancing
     */
    private FogDevice getWeightedDevice() {
        int totalWeight = weights.values().stream().mapToInt(Integer::intValue).sum();
        int randomValue = (int) (Math.random() * totalWeight); // Generate a random number within total weight

        for (Map.Entry<FogDevice, Integer> entry : weights.entrySet()) {
            FogDevice device = entry.getKey();
            int weight = entry.getValue();
            if (randomValue < weight) {
                return device;
            }
            randomValue -= weight;
        }
        return null;
    }

    /**
     * Select the next device using Round-Robin
     */
    private FogDevice getNextRoundRobinDevice() {
        if (devices.isEmpty()) {
            return null;
        }
        FogDevice selectedDevice = devices.get(currentIndex);
        currentIndex = (currentIndex + 1) % devices.size(); // Move to the next device in a circular manner
        return selectedDevice;
    }

    /**
     * Update latency values dynamically (this can be called during the simulation)
     */
    public void updateLatencies(Map<FogDevice, Double> newLatencies) {
        for (FogDevice device : devices) {
            if (newLatencies.containsKey(device)) {
                latencyMap.put(device, newLatencies.get(device));
            }
        }
    }

    /**
     * Update device weights dynamically based on resource usage
     */
    public void updateWeights(Map<FogDevice, Integer> newWeights) {
        for (FogDevice device : devices) {
            if (newWeights.containsKey(device)) {
                weights.put(device, newWeights.get(device));
            }
        }
    }

    /**
     * Print load balancer status for debugging
     */
    public void printStatus() {
        System.out.println("====== Hybrid Load Balancer Status ======");
        System.out.println("Weights:");
        for (Map.Entry<FogDevice, Integer> entry : weights.entrySet()) {
            System.out.println("Device: " + entry.getKey().getName() + ", Weight: " + entry.getValue());
        }
        System.out.println("Latencies:");
        for (Map.Entry<FogDevice, Double> entry : latencyMap.entrySet()) {
            System.out.println("Device: " + entry.getKey().getName() + ", Latency: " + entry.getValue());
        }
        System.out.println("==========================================");
    }
}
