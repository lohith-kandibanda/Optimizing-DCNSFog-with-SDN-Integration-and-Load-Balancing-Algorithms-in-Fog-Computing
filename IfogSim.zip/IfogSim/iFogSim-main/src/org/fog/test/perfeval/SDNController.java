package org.fog.test.perfeval;

import org.fog.entities.FogDevice;

import java.util.*;

public class SDNController {
	private List<FogDevice> fogDevices;
	private Map<Integer, Map<Integer, Double>> routingTable; // Maps device IDs to other device IDs with their latencies

	public SDNController(List<FogDevice> fogDevices) {
		this.fogDevices = fogDevices;
		this.routingTable = new HashMap<>();
		initializeRoutingTable();
	}

	// Initialize routing table with default latencies
	private void initializeRoutingTable() {
		for (FogDevice source : fogDevices) {
			Map<Integer, Double> latencies = new HashMap<>();
			for (FogDevice target : fogDevices) {
				if (!source.equals(target)) {
					latencies.put(target.getId(), source.getUplinkLatency());
				}
			}
			routingTable.put(source.getId(), latencies);
		}
	}

	// Get the next hop for a given source and destination
	public FogDevice getNextHop(FogDevice source, FogDevice destination) {
		int sourceId = source.getId();
		int destId = destination.getId();

		Map<Integer, Double> latencies = routingTable.get(sourceId);
		if (latencies == null || !latencies.containsKey(destId)) {
			return null; // No valid route
		}

		double minLatency = Double.MAX_VALUE;
		FogDevice nextHop = null;

		for (FogDevice device : fogDevices) {
			double latency = latencies.getOrDefault(device.getId(), Double.MAX_VALUE);
			if (latency < minLatency) {
				minLatency = latency;
				nextHop = device;
			}
		}

		return nextHop;
	}

	// Update routing table based on real-time metrics
	public void updateRouting() {
		for (FogDevice source : fogDevices) {
			Map<Integer, Double> updatedLatencies = new HashMap<>();
			for (FogDevice target : fogDevices) {
				if (!source.equals(target)) {
					// Example: Real-time latency can be measured and updated here
					double latency = measureLatency(source, target);
					updatedLatencies.put(target.getId(), latency);
				}
			}
			routingTable.put(source.getId(), updatedLatencies);
		}
	}

	// Example function to simulate latency measurement (replace with real metrics)
	private double measureLatency(FogDevice source, FogDevice target) {
		return source.getUplinkLatency() + Math.random(); // Add random variation
	}

	// Display routing table for debugging
	public void printRoutingTable() {
		System.out.println("Routing Table:");
		for (Map.Entry<Integer, Map<Integer, Double>> entry : routingTable.entrySet()) {
			int sourceId = entry.getKey();
			System.out.println("Source: " + sourceId);
			for (Map.Entry<Integer, Double> destEntry : entry.getValue().entrySet()) {
				System.out.println("  Destination: " + destEntry.getKey() + " Latency: " + destEntry.getValue());
			}
		}
	}
}
